#include "genus.h"

//Genus class - no code in current implementation

Genus::Genus()
{
    rootnode=0;
}

Genus::~Genus()
{

}

